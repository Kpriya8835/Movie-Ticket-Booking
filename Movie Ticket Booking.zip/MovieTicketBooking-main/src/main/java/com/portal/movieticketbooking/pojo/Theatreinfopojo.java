package com.portal.movieticketbooking.pojo;

public class Theatreinfopojo {
	public MovieInfoPojo reqpojo;
	public String thname;
	public MovieInfoPojo getMoviep() {
		return reqpojo;
	}
	public void setMoviep(MovieInfoPojo reqpojo) {
		this.reqpojo = reqpojo;
	}
	public String getThname() {
		return thname;
	}
	public void setThname(String thname) {
		this.thname = thname;
	}
	
}
