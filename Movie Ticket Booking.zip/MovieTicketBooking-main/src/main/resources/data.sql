insert into movie_desc_mstr(Id,Moviename,Theatrename,Startdate,Starttime,Enddate,Endtime,Seats,Status) VALUES(1,'Movie5','Theatre5','2025-01-01','20:00:00','2025-01-01','23:00',15,'Y')

insert into seat_dtls_mstr(Id,Moviedescid,Seatno,Status) VALUES(1,1,1,'N')
insert into seat_dtls_mstr(Id,Moviedescid,Seatno,Status) VALUES(2,1,2,'N')
insert into seat_dtls_mstr(Id,Moviedescid,Seatno,Status) VALUES(3,1,3,'Y')
insert into seat_dtls_mstr(Id,Moviedescid,Seatno,Status) VALUES(4,1,4,'N')
insert into seat_dtls_mstr(Id,Moviedescid,Seatno,Status) VALUES(5,1,5,'N')
insert into seat_dtls_mstr(Id,Moviedescid,Seatno,Status) VALUES(6,1,6,'N')
insert into seat_dtls_mstr(Id,Moviedescid,Seatno,Status) VALUES(7,1,7,'N')
insert into seat_dtls_mstr(Id,Moviedescid,Seatno,Status) VALUES(8,1,8,'Y')
insert into seat_dtls_mstr(Id,Moviedescid,Seatno,Status) VALUES(9,1,9,'N')


insert into sch_mstr(id,ldate) VALUES(1,'')






